# cell.py

class Cell:
    """
    کلاس `Cell`
    نماینده یک خانه (سلول) در نقشه بازی.
    """
    def __init__(self, value):
        self.value = value
        self.is_thief = (value == '!')
        self.is_treasure = (isinstance(value, int) and value > 0)
        self.is_normal_cost = (isinstance(value, int) and value < 0)
        self.is_zero = (isinstance(value, int) and value == 0) # برای خانه های با مقدار صفر

    def __repr__(self):
        return f"Cell({self.value})"