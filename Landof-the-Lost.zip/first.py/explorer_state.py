# explorer_state.py

class ExplorerState:
    def __init__(self, r, c, current_gold, stolen_gold, has_thief, path):
        self.r = r
        self.c = c
        self.current_gold = current_gold
        self.stolen_gold = stolen_gold
        self.has_thief = has_thief # True if thief is in the car, False otherwise
        self.path = path # List of (r, c) tuples for the path taken so far

    # برای استفاده در set ها و dictionary ها (مثل visited_states)
    def __hash__(self):
        return hash((self.r, self.c, self.has_thief))

    def __eq__(self, other):
        if not isinstance(other, ExplorerState):
            return NotImplemented
        return self.r == other.r and \
               self.c == other.c and \
               self.has_thief == other.has_thief

    # برای نمایش در دیباگ
    def __repr__(self):
        return f"State(r={self.r}, c={self.c}, gold={self.current_gold}, stolen={self.stolen_gold}, thief={self.has_thief})"