# game_logic.py

from cell import Cell


class GameLogic:
    """
    کلاس `GameLogic`
    قوانین حرکت و تعامل با خانه‌ها را محصور می‌کند.
    """

    @staticmethod
    def calculate_effect(current_cell: Cell, next_cell: Cell, has_thief_before_move: bool):
        """
        تغییر طلا، طلای دزدیده شده و وضعیت دزد را پس از حرکت *به داخل* next_cell محاسبه می‌کند.
        فرض می‌شود آریان در `current_cell` بوده و اکنون به `next_cell` وارد شده است.

        Args:
            current_cell (Cell): سلولی که آریان از آن حرکت کرده است (موقعیت قبلی).
            next_cell (Cell): سلولی که آریان به آن وارد شده است (موقعیت فعلی).
            has_thief_before_move (bool): آیا آریان قبل از ورود به `next_cell`، دزد در ماشین داشته است؟

        Returns:
            tuple: (gold_change, stolen_this_move, has_thief_after_move)
                - gold_change (int): تغییر در سکه‌های آریان (مثبت برای سود، منفی برای هزینه).
                - stolen_this_move (int): مقدار طلای دزدیده شده در این حرکت.
                - has_thief_after_move (bool): وضعیت دزد در ماشین آریان پس از این حرکت.
        """
        gold_change = 0
        stolen_this_move = 0
        has_thief_after_move = has_thief_before_move

        # Scenario 1: Arian just moved FROM a thief cell (current_cell is '!')
        if current_cell.is_thief:
            if has_thief_before_move:
                # Arian had a thief, now coming from another thief cell.
                # Two thieves fought. The thief in the car exits. No stealing happens.
                has_thief_after_move = False
            else:
                # Arian did not have a thief, but current_cell (the one just left) was a thief cell.
                # A new thief just entered the car from current_cell.
                has_thief_after_move = True

            # Important: The effect of next_cell_value (where Arian just arrived) is ONLY applied
            # if the thief just exited (or was never present).
            # If a new thief *just entered* (has_thief_after_move is True), they don't
            # act on this immediate next_cell's value; their actions start from the *next* move.
            if not has_thief_after_move and isinstance(next_cell.value, int):
                # Apply next_cell's value normally, as no thief is in action right now
                gold_change = next_cell.value

        # Scenario 2: Arian had a thief in the car (from previous moves, current_cell was not '!')
        elif has_thief_before_move:
            if next_cell.is_thief:
                # Thief in car meets another thief cell. Thief exits. No stealing.
                has_thief_after_move = False
            elif next_cell.is_treasure:
                # Thief in car, enters treasure cell. Thief steals. Arian gets 0. Thief exits.
                stolen_this_move = next_cell.value
                gold_change = 0  # Arian gets no gold from this treasure
                has_thief_after_move = False
            elif next_cell.is_normal_cost:
                # Thief in car, enters negative cost cell. Thief steals cost. Arian still pays. Thief exits.
                stolen_this_move = abs(next_cell.value)
                gold_change = next_cell.value  # Arian pays the cost
                has_thief_after_move = False
            elif next_cell.is_zero:
                # Thief in car, enters zero cell. Thief exits. No stealing/gold change.
                gold_change = 0
                stolen_this_move = 0
                has_thief_after_move = False
            else:  # Fallback for any other int cell value, though problem implies only >0, <0, 0
                gold_change = 0
                stolen_this_move = 0
                has_thief_after_move = False  # Thief exits regardless

        # Scenario 3: Arian does NOT have a thief in the car (current_cell was not '!')
        else:  # not has_thief_before_move
            if next_cell.is_thief:
                # Arian enters a thief cell. Thief enters car.
                has_thief_after_move = True
            elif isinstance(next_cell.value, int):
                # Arian enters a normal integer cell (treasure, cost, or zero).
                gold_change = next_cell.value

        return gold_change, stolen_this_move, has_thief_after_move