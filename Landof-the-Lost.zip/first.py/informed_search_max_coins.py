# informed_search_max_coins.py (or informed.py, if you prefer)

import heapq
from search_algorithm import SearchAlgorithm
from explorer_state import ExplorerState
from map import Map


class InformedSearchMaxCoins(SearchAlgorithm):
    """
    کلاس برای جستجوی آگاهانه برای یافتن مسیری با بیشترین سود.
    """

    def __init__(self, map_object: Map):
        super().__init__(map_object)
        self.priority_queue = []
        # visited_states: (r, c, has_thief) -> (-max_gold_reached, min_stolen_gold_at_that_max_gold)
        self.visited_states = {}

    def heuristic(self, r: int, c: int) -> int:
        """
        هیوریستیک: تخمین حداکثر طلای ممکن در آینده از (r, c) تا انتها.
        این هیوریستیک "خوش‌بینانه" است، زیرا فرض می‌کند آریان به تمام گنجینه‌های ممکن خواهد رسید
        و هیچ دزدی/هزینه‌ای رخ نمی‌دهد. این هیوریستیک برای مسئله بیشینه‌سازی معتبر است.
        """
        h_val = 0
        for row_idx in range(r, self.n):
            start_col_in_row = c if row_idx == r else 0
            for col_idx in range(start_col_in_row, self.n):
                cell_value = self.map_object.matrix[row_idx][col_idx]
                if isinstance(cell_value, int) and cell_value > 0:
                    h_val += cell_value
        return h_val

    def find_path(self):
        """
        جستجوی A* را برای یافتن مسیری با بیشترین سود انجام می‌دهد.

        Returns:
            tuple: یک تاپل شامل (مسیر_تاپل‌های_مختصات, سکه_نهایی, ضرر_نهایی, جزئیات_مسیر).
                   اگر مسیری پیدا نشود، (None, None, None, None) برمی‌گرداند.
        """
        start_r, start_c = self.start
        end_r, end_c = self.end

        # Initialize the state based on the starting cell (0,0)
        initial_gold_val, initial_stolen_val, initial_has_thief_val = self.map_object.get_initial_state_values()

        initial_state = ExplorerState(
            start_r, start_c, initial_gold_val, initial_stolen_val, initial_has_thief_val, [(start_r, start_c)]
        )

        # A* f_cost for maximization: -(current_gold + heuristic_value)
        # We want to minimize this negative value, which maximizes the positive sum.
        # Tie-breaking in heapq: if f_cost is same, prefer more gold (-current_gold)
        # if f_cost and gold are same, prefer less stolen_gold (stolen_gold)
        initial_f_cost = -(initial_gold_val + self.heuristic(start_r, start_c))
        heapq.heappush(self.priority_queue,
                       (initial_f_cost, -initial_gold_val, initial_stolen_val, initial_state))

        # visited_states stores the BEST (r, c, has_thief) state encountered so far
        # Best means: max gold, then min stolen for tie-breaking
        self.visited_states[(start_r, start_c, initial_has_thief_val)] = (-initial_gold_val, initial_stolen_val)

        while self.priority_queue:
            f_cost, neg_current_coins_pq, current_stolen_gold_pq, current_state = heapq.heappop(self.priority_queue)
            r, c, current_gold, stolen_gold, has_thief, path = \
                current_state.r, current_state.c, current_state.current_gold, \
                    current_state.stolen_gold, current_state.has_thief, current_state.path

            # If a better or equally good state has already been processed, skip this one
            # The order of conditions in visited_states check is crucial for optimality
            if (r, c, has_thief) in self.visited_states:
                stored_neg_gold, stored_stolen = self.visited_states[(r, c, has_thief)]
                if -current_gold < stored_neg_gold or \
                        (-current_gold == stored_neg_gold and stolen_gold > stored_stolen):
                    continue  # This path is worse or same in gold but more stolen

            if (r, c) == (end_r, end_c):
                final_coins, total_robbed, path_details = self.map_object.calculate_path_cost(path)
                return path, final_coins, total_robbed, path_details

            neighbors = self.map_object.get_neighbors(r, c)
            current_cell_value_on_map = self.map_object.matrix[r][c]  # Value of the cell Arian is currently leaving

            for nr, nc in neighbors:
                next_cell_value_on_map = self.map_object.matrix[nr][nc]

                # Recalculate effects of moving to next_cell based on the exact GameLogic rules
                gold_change_this_move = 0
                stolen_this_move = 0
                new_has_thief = has_thief  # Assume no change unless specified

                if has_thief:  # Arian is carrying a thief
                    if next_cell_value_on_map == '!':
                        new_has_thief = False  # Thief exits
                    elif isinstance(next_cell_value_on_map, int):
                        if next_cell_value_on_map > 0:  # Treasure
                            stolen_this_move = next_cell_value_on_map
                            gold_change_this_move = 0
                            new_has_thief = False
                        elif next_cell_value_on_map < 0:  # Cost
                            stolen_this_move = abs(next_cell_value_on_map)
                            gold_change_this_move = next_cell_value_on_map
                            new_has_thief = False
                        elif next_cell_value_on_map == 0:  # Zero value
                            gold_change_this_move = 0
                            stolen_this_move = 0
                            new_has_thief = False
                else:  # Arian does NOT have a thief
                    if next_cell_value_on_map == '!':
                        new_has_thief = True
                    elif isinstance(next_cell_value_on_map, int):
                        gold_change_this_move = next_cell_value_on_map

                new_gold = current_gold + gold_change_this_move
                new_stolen_gold = stolen_gold + stolen_this_move

                next_state_key = (nr, nc, new_has_thief)

                # Update visited_states if this path is better
                # Better means: more gold, or same gold with less stolen
                if next_state_key not in self.visited_states or \
                        (-new_gold > self.visited_states[next_state_key][0]) or \
                        (-new_gold == self.visited_states[next_state_key][0] and new_stolen_gold <
                         self.visited_states[next_state_key][1]):
                    self.visited_states[next_state_key] = (-new_gold, new_stolen_gold)
                    new_path = path + [(nr, nc)]

                    new_state = ExplorerState(nr, nc, new_gold, new_stolen_gold, new_has_thief, new_path)
                    new_f_cost = -(new_gold + self.heuristic(nr, nc))
                    heapq.heappush(self.priority_queue, (new_f_cost, -new_gold, new_stolen_gold, new_state))
        return None, None, None, []