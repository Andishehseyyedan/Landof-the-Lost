# informed_search_min_robbed.py

import heapq
from search_algorithm import SearchAlgorithm
from map import Map


class InformedSearchMinRobbed(SearchAlgorithm):
    """
    کلاس برای جستجوی آگاهانه برای یافتن مسیری با کمترین ضرر.
    """

    def __init__(self, map_object):
        super().__init__(map_object)
        # (f_cost, g_cost_stolen, -h_cost_gold, (row, col), path, has_thief)
        # f_cost: stolen_gold + heuristic
        # g_cost_stolen: current_stolen_gold (for tie-breaking on actual stolen amount)
        # -h_cost_gold: negative of current_gold (for tie-breaking: prefer higher gold if stolen is tied)
        self.priority_queue = []
        # visited_states: (r, c, has_thief) -> (min_stolen_gold_reached, max_gold_at_this_stolen_level)
        self.visited_states = {}

    def heuristic(self, row, col):
        """
        هیورستیک: تخمین حداقل ضرر تا مقصد.
        برای تضمین اعتبار (admissibility) در A* برای مشکل کمینه کردن،
        این هیوریستیک هرگز نباید هزینه واقعی باقی‌مانده را بیش از حد تخمین بزند.
        ساده‌ترین هیوریستیک معتبر، صفر است.
        """
        return 0

    def find_path(self):
        """
        جستجوی A* را برای یافتن مسیری با کمترین ضرر انجام می‌دهد.

        Returns:
            tuple: یک تاپل شامل (مسیر, سکه_نهایی, ضرر_نهایی, جزئیات_مسیر).
        """
        start_row, start_col = self.start

        # Initial state calculation (similar to how calculate_path_cost starts)
        initial_coins = 0
        initial_stolen_gold = 0
        initial_has_thief = False

        start_cell_value = self.map_object.matrix[start_row][start_col]
        if start_cell_value == '!':
            initial_has_thief = True
        elif isinstance(start_cell_value, int):
            initial_coins += start_cell_value

        # Initial path (only start cell)
        initial_path = [(start_row, start_col)]

        # Push initial state to priority queue
        # (f_cost, current_stolen_gold, -current_coins, (r,c), path, has_thief)
        initial_f_cost = initial_stolen_gold + self.heuristic(start_row, start_col)
        heapq.heappush(self.priority_queue,
                       (initial_f_cost, initial_stolen_gold, -initial_coins,
                        (start_row, start_col), initial_path, initial_has_thief))

        # Store visited states to avoid redundant processing and find better paths to same state
        # (row, col, has_thief) -> (min_stolen_gold_reached_at_this_state, max_coins_at_this_stolen_level)
        self.visited_states[(start_row, start_col, initial_has_thief)] = (initial_stolen_gold, initial_coins)

        while self.priority_queue:
            f_cost, current_stolen_gold_pq, neg_current_coins_pq, (row, col), path, has_thief = heapq.heappop(
                self.priority_queue)
            current_coins = -neg_current_coins_pq

            # Check if we have found a better path to this state already
            if (row, col, has_thief) in self.visited_states:
                stored_stolen, stored_coins = self.visited_states[(row, col, has_thief)]
                # If current path is worse or same in stolen, AND has less coins, skip
                if current_stolen_gold_pq > stored_stolen or \
                        (current_stolen_gold_pq == stored_stolen and current_coins < stored_coins):
                    continue

            if (row, col) == self.end:
                # Once the end is reached, use calculate_path_cost to get final gold, stolen, and path_details
                final_coins, total_robbed, path_details = self.map_object.calculate_path_cost(path)
                return path, final_coins, total_robbed, path_details

            neighbors = self.map_object.get_neighbors(row, col)
            current_cell_value_on_map = self.map_object.matrix[row][col]  # Value of the cell Arian is currently leaving

            for next_row, next_col in neighbors:
                next_cell_value_on_map = self.map_object.matrix[next_row][next_col]

                # Recalculate effects of moving to next_cell based on the exact GameLogic rules
                gold_change_this_move = 0
                stolen_this_move = 0
                new_has_thief = has_thief

                # Rule for current cell (row, col) affecting the *next* move
                if current_cell_value_on_map == '!':  # Arian just left a '!' cell
                    if has_thief:  # Was carrying a thief, and left another '!'
                        new_has_thief = False  # Thieves fought, thief leaves car.
                        if isinstance(next_cell_value_on_map, int):
                            gold_change_this_move = next_cell_value_on_map  # Effect of next_cell_value applied normally.
                    else:  # Was not carrying a thief, entered '!' (prev_cell)
                        new_has_thief = True  # Thief just entered the car.
                        # No gold_change or stolen_this_move from next_cell_value when thief just entered.

                # If current cell was not '!'
                else:
                    if has_thief:  # Arian is carrying a thief in the car
                        if next_cell_value_on_map == '!':  # Thief in car meets another thief cell
                            new_has_thief = False  # Thief exits car. No stealing.
                        elif isinstance(next_cell_value_on_map, int):
                            if next_cell_value_on_map > 0:  # Treasure cell
                                stolen_this_move = next_cell_value_on_map  # Thief steals the treasure
                                gold_change_this_move = 0  # Arian gets 0 from this treasure
                                new_has_thief = False  # Thief exits car
                            elif next_cell_value_on_map < 0:  # Normal cost cell (negative value)
                                stolen_this_move = abs(next_cell_value_on_map)  # Thief steals cost
                                gold_change_this_move = next_cell_value_on_map  # Arian still pays the cost
                                new_has_thief = False  # Thief exits car
                            elif next_cell_value_on_map == 0:  # Zero value cell
                                gold_change_this_move = 0
                                stolen_this_move = 0
                                new_has_thief = False  # Thief exits

                    else:  # Arian does NOT have a thief in the car
                        if next_cell_value_on_map == '!':
                            new_has_thief = True  # Thief enters car
                        elif isinstance(next_cell_value_on_map, int):
                            gold_change_this_move = next_cell_value_on_map  # Arian gets/pays value normally

                new_gold = current_coins + gold_change_this_move
                new_stolen_gold = stolen_gold + stolen_this_move

                next_state_key = (nr, nc, new_has_thief)

                # Update visited_states if this path is better
                # Better means: less stolen gold, or same stolen gold with more gold
                if next_state_key not in self.visited_states or \
                        (new_stolen_gold < self.visited_states[next_state_key][0]) or \
                        (new_stolen_gold == self.visited_states[next_state_key][0] and new_gold >
                         self.visited_states[next_state_key][1]):
                    self.visited_states[next_state_key] = (new_stolen_gold, new_gold)
                    new_path = path + [(nr, nc)]

                    new_f_cost = new_stolen_gold + self.heuristic(nr, nc)
                    heapq.heappush(self.priority_queue, (new_f_cost, new_stolen_gold, -new_gold,
                                                         (nr, nc), new_path, new_has_thief))
        return None, None, None, []  # No path found