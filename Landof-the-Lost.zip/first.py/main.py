# main.py

from map import Map
from uninformed_search import UninformedSearch
from informed_search_max_coins import InformedSearchMaxCoins # Assuming this is the correct name
from informed_search_min_robbed import InformedSearchMinRobbed
from output_formatter import output # Use your Output class

class Main:
    """
    کلاس اصلی که نقشه را می‌خواند، الگوریتم‌های جستجو را اجرا می‌کند و نتایج را چاپ می‌کند.
    """
    def __init__(self):
        self.map_object = Map.read_map()
        self.output_printer = output() # Initialize your Output class

    def run(self):
        """
        الگوریتم های جستجو را اجرا می کند و نتایج را چاپ می کند.
        """
        print("مسیر برای حالت 1:")
        search1 = UninformedSearch(self.map_object)
        path1, coins1, robbed1, path_details1 = search1.find_path() # find_path returns all
        self.output_printer.print_result(path1, coins1, robbed1, 1, self.map_object.matrix)
        print("-" * 20)

        print("مسیر برای حالت 2:")
        search2 = InformedSearchMaxCoins(self.map_object)
        path2, coins2, robbed2, path_details2 = search2.find_path()
        self.output_printer.print_result(path2, coins2, robbed2, 2, self.map_object.matrix)
        print("-" * 20)

        print("مسیر برای حالت 3:")
        search3 = InformedSearchMinRobbed(self.map_object)
        path3, coins3, robbed3, path_details3 = search3.find_path()
        self.output_printer.print_result(path3, coins3, robbed3, 3, self.map_object.matrix)
        print("-" * 20)

if __name__ == "__main__":
    main_instance = Main()
    main_instance.run()