class Map:
    """
    کلاس برای نگهداری و مدیریت نقشه سرزمین گمشدگان.
    """

    def __init__(self, n, matrix):
        self.n = n
        self.matrix = matrix

    @staticmethod
    def read_map():
        n = int(input())
        matrix = []
        for _ in range(n):
            row = input().split()
            row = [int(x) if x.lstrip('-').isdigit() else x for x in row]
            matrix.append(row)
        return Map(n, matrix)

    def is_valid(self, row, col):
        return 0 <= row < self.n and 0 <= col < self.n

    def get_neighbors(self, row, col):
        neighbors = []
        if self.is_valid(row + 1, col):
            neighbors.append((row + 1, col))  # Down
        if self.is_valid(row, col + 1):
            neighbors.append((row, col + 1))  # Right
        return neighbors

    def get_initial_state_values(self):
        """
        مقادیر اولیه (سکه، دزدی، وضعیت دزد) را بر اساس خانه (0,0) محاسبه می‌کند.
        """
        start_cell_value = self.matrix[0][0]
        initial_gold = 0
        initial_stolen = 0
        initial_has_thief = False

        if start_cell_value == '!':
            initial_has_thief = True
        elif isinstance(start_cell_value, int):
            initial_gold = start_cell_value

        return initial_gold, initial_stolen, initial_has_thief

    def calculate_path_cost(self, path):
        """
        تغییرات سکه، دزدی و وضعیت دزد را برای یک مسیر مشخص محاسبه می‌کند.
        این تابع قوانین بازی را با دقت پیاده‌سازی می‌کند.

        Args:
            path (list): لیستی از تاپل‌های (row, col) که مسیر را نشان می‌دهند.

        Returns:
            tuple: (final_coins, total_robbed, path_details)
                - final_coins (int): سکه نهایی آریان.
                - total_robbed (int): کل سکه‌های دزدیده شده.
                - path_details (list): لیستی از [(position, coins_at_position)] برای هر خانه در مسیر.
        """
        if not path:
            return 0, 0, []

        current_gold, total_robbed, has_thief = self.get_initial_state_values()
        path_details = [((path[0][0], path[0][1]), current_gold)]  # Add initial state *after* (0,0) is processed

        # Iterate from the first actual move (second element in path)
        for i in range(len(path) - 1):
            prev_row, prev_col = path[i]
            next_row, next_col = path[i + 1]
            next_cell_value = self.matrix[next_row][next_col]

            gold_change_this_move = 0
            stolen_this_move = 0
            new_has_thief = has_thief  # Assume thief status doesn't change unless specified

            # Determine the effect based on current thief status and next cell value
            if has_thief:  # Arian is carrying a thief
                if next_cell_value == '!':
                    new_has_thief = False  # Thief exits, no stealing
                elif isinstance(next_cell_value, int):
                    if next_cell_value > 0:  # Treasure
                        stolen_this_move = next_cell_value  # Thief steals it
                        gold_change_this_move = 0  # Arian gets nothing
                        new_has_thief = False  # Thief exits
                    elif next_cell_value < 0:  # Cost
                        stolen_this_move = abs(next_cell_value)  # Thief steals cost
                        gold_change_this_move = next_cell_value  # Arian still pays
                        new_has_thief = False  # Thief exits
                    elif next_cell_value == 0:  # Zero value
                        gold_change_this_move = 0
                        stolen_this_move = 0
                        new_has_thief = False  # Thief exits
            else:  # Arian does NOT have a thief
                if next_cell_value == '!':
                    new_has_thief = True  # Thief enters car
                elif isinstance(next_cell_value, int):
                    gold_change_this_move = next_cell_value  # Arian gets/pays value normally

            current_gold += gold_change_this_move
            total_robbed += stolen_this_move
            has_thief = new_has_thief

            path_details.append(((next_row, next_col), current_gold))

        return current_gold, total_robbed, path_details