class output:
    """Class for outputting results."""

    def print_result(self, path, coins, damage, scenario, matrix):
        """Print the result of the search."""
        if path:
            print(f"Path for scenario {scenario}:")

            # Initial coins are based on the (0,0) cell after it's processed.
            # This is handled by map.calculate_path_cost and passed as `coins` for the path.
            # To match your example "در ابتدا آریان از خانه اول شروع کرده و سکه‌های او -3 می‌شود.",
            # we directly take the value of matrix[0][0] if it's an int.
            initial_val_0_0 = matrix[0][0]
            if not isinstance(initial_val_0_0, int):  # If it's '!', initial coins should be 0.
                initial_val_0_0 = 0  # Or whatever rule applies for '!' at start.
                # The `coins` passed in should reflect this initial state.

            # The `coins` parameter to this function is the FINAL coins.
            # We need the coins *after* the first cell processing for the "Initially" line.
            # `path_details` (which is not passed here directly but calculated inside `calculate_path_cost`)
            # would be ideal. Since `Output.py` receives just `path`, `coins`, `damage`,
            # we need to re-derive the initial coins as per your specific output format.

            # Let's assume the `coins` variable passed to print_result is the final_coins,
            # and we need to re-calculate initial_coins based on matrix[0][0] for the specific output string.
            # This is a bit inconsistent with the passed `coins` but matches your desired print format.
            initial_printed_coins = 0
            if isinstance(matrix[0][0], int):
                initial_printed_coins = matrix[0][0]

            print(f"در ابتدا آریان از خانه اول شروع کرده و سکه‌های او {initial_printed_coins} می‌شود.")
            print("ادامه مسیر او به شکل زیر است:")

            # Print moves
            for i in range(len(path) - 1):  # Iterate from the first actual move (second element in path)
                row_prev, col_prev = path[i]
                row_curr, col_curr = path[i + 1]

                direction = ""
                if row_curr > row_prev:
                    direction = "پایین"
                else:  # next_col > col_prev
                    direction = "راست"

                cell_value_entered = matrix[row_curr][col_curr]
                print(f"{direction} ({cell_value_entered})")

            print(f"در نهایت سکه‌های او {coins} می‌شود و سکه‌های دزدیده‌شده از او (ضرر) {damage} خواهد بود.")
        else:
            print(f"No path found for scenario {scenario}.")