# search_algorithm.py
from map import Map

class SearchAlgorithm:
    def __init__(self, map_object: Map):
        self.map_object = map_object
        self.n = map_object.n
        self.start = (0, 0)
        self.end = (self.n - 1, self.n - 1)

    def find_path(self):
        """
        مسیر را جستجو می کند (باید توسط کلاس های فرزند پیاده سازی شود).
        Returns:
            tuple: یک تاپل شامل (مسیر, سکه_نهایی, ضرر_نهایی, جزئیات_مسیر).
                   اگر مسیری پیدا نشود، (None, None, None, None) برمی‌گرداند.
        """
        raise NotImplementedError("Subclasses must implement this method")