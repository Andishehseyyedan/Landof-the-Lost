# uninformed_search.py

from collections import deque
from search_algorithm import SearchAlgorithm
from explorer_state import ExplorerState  # Import the new State class
from map import Map


class UninformedSearch(SearchAlgorithm):
    """
    کلاس برای جستجوی ناآگاهانه (BFS).
    """

    def __init__(self, map_object: Map):
        super().__init__(map_object)
        self.queue = deque()
        # visited will store (r, c, has_thief) to avoid revisiting states with same thief status
        self.visited = set()

    def find_path(self):
        """
        جستجوی ناآگاهانه (BFS) را برای یافتن یک مسیر ساده از مبدا به مقصد انجام می‌دهد.
        این الگوریتم به سکه‌ها و دزدها "اهمیت نمی‌دهد" اما آنها را برای خروجی ردیابی می‌کند.

        Returns:
            tuple: یک تاپل شامل (مسیر_تاپل‌های_مختصات, سکه_نهایی, ضرر_نهایی, جزئیات_مسیر).
                   اگر مسیری پیدا نشود، (None, None, None, None) برمی‌گرداند.
        """
        start_r, start_c = self.start
        end_r, end_c = self.end

        # Initialize the state based on the starting cell (0,0)
        initial_gold_val, initial_stolen_val, initial_has_thief_val = self.map_object.get_initial_state_values()

        initial_state = ExplorerState(
            start_r, start_c, initial_gold_val, initial_stolen_val, initial_has_thief_val, [(start_r, start_c)]
        )
        self.queue.append(initial_state)
        self.visited.add((start_r, start_c, initial_has_thief_val))

        while self.queue:
            current_state: ExplorerState = self.queue.popleft()
            r, c, current_gold, stolen_gold, has_thief, path = \
                current_state.r, current_state.c, current_state.current_gold, \
                    current_state.stolen_gold, current_state.has_thief, current_state.path

            if (r, c) == (end_r, end_c):
                # Now that we have the path, use map.calculate_path_cost to get final details
                final_coins, total_robbed, path_details = self.map_object.calculate_path_cost(path)
                return path, final_coins, total_robbed, path_details

            neighbors = self.map_object.get_neighbors(r, c)
            # We need the value of the cell Arian is *leaving* to apply game rules correctly
            current_cell_value = self.map_object.matrix[r][c]

            for nr, nc in neighbors:
                next_cell_value = self.map_object.matrix[nr][nc]

                # Calculate effects of moving from current_cell to next_cell
                gold_change_this_move = 0
                stolen_this_move = 0
                new_has_thief = has_thief  # Assume no change unless specified

                if has_thief:  # Arian is carrying a thief
                    if next_cell_value == '!':
                        new_has_thief = False  # Thief exits
                    elif isinstance(next_cell_value, int):
                        if next_cell_value > 0:  # Treasure
                            stolen_this_move = next_cell_value
                            gold_change_this_move = 0
                            new_has_thief = False
                        elif next_cell_value < 0:  # Cost
                            stolen_this_move = abs(next_cell_value)
                            gold_change_this_move = next_cell_value
                            new_has_thief = False
                        elif next_cell_value == 0:  # Zero value
                            gold_change_this_move = 0
                            stolen_this_move = 0
                            new_has_thief = False
                else:  # Arian does NOT have a thief
                    if next_cell_value == '!':
                        new_has_thief = True
                    elif isinstance(next_cell_value, int):
                        gold_change_this_move = next_cell_value

                new_gold = current_gold + gold_change_this_move
                new_stolen_gold = stolen_gold + stolen_this_move

                next_state_key = (nr, nc, new_has_thief)

                if next_state_key not in self.visited:
                    self.visited.add(next_state_key)
                    new_path = path + [(nr, nc)]
                    next_state = ExplorerState(nr, nc, new_gold, new_stolen_gold, new_has_thief, new_path)
                    self.queue.append(next_state)
        return None, None, None, None